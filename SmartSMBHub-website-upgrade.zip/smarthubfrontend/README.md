# SmartSMBHub marketing and SEO upgrade

Start with **LAUNCH-AND-SEO.md**. This package contains an updated marketing frontend and focused test results; it has not been deployed or validated with a full Next.js production build.

## Local development

```sh
npm ci
# Copy .env.local.example to .env.local and configure real values privately.
npm run dev
```

## Before deployment

```sh
npm run build
```

Use a Git branch and Vercel Preview before production. Never commit secrets. Configure either a native Notion form embed or the Resend email form. Review the launch gates in the guide, especially retained legal, account, pricing, security, and service-delivery assumptions.

Original LICENSE retained.
